import React, { useEffect } from "react";
import { View, Button } from "react-native";
//import { setupDatabase, insertTransaction } from "./database";
//import ChartScreen from "./chart";

export default function App() {
  useEffect(() => {
    //setupDatabase();
  }, []);

  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      
    </View>
  );
}
